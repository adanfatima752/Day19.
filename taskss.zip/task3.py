# Creating a tuple with three elements
fruits = ('apple', 'banana', 'cherry')

try:
    # Attempting to change the second element of the tuple
    fruits[1] = 'orange'
except TypeError as e:
    print(f"Error: {e}. Tuples are immutable, so you cannot change their elements.")
