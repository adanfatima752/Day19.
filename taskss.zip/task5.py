def swap_values(a, b):
    """
    This function swaps the values of two variables using tuple assignment.
    """
    a, b = b, a
    return a, b

# Example usage
a = 5
b = 10

# Swapping the values
a, b = swap_values(a, b)

# Printing the swapped values
print(f"a = {a}, b = {b}")
