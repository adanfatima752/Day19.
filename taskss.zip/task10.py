def reverse_and_sort_dict(dictionary):
    return sorted([(v, k) for k, v in dictionary.items()])

# Example usage:
my_dict = {'a': 10, 'b': 1, 'c': 22}
result = reverse_and_sort_dict(my_dict)
print(result)
