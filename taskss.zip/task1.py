# Creating a tuple with three names
names = ('Alice', 'Bob', 'Charlie')

# Printing the second name in the tuple
print(names[1])
