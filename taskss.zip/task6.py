def dict_to_tuples(dictionary):
    return list(dictionary.items())

# Example usage:
my_dict = {'x': 1, 'y': 2, 'z': 3}
result = dict_to_tuples(my_dict)
print(result)
