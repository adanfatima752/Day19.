def compare_tuples(tuple1, tuple2):
    return [a == b for a, b in zip(tuple1, tuple2)]

# Example usage:
tuple1 = (1, 2, 3)
tuple2 = (3, 2, 1)
result = compare_tuples(tuple1, tuple2)
print(result)
