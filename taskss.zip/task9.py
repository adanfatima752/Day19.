from collections import Counter
import re

def top_n_common_words(filename, N):
    with open(filename, 'r') as file:
        text = file.read().lower()  # Convert to lowercase to count words in a case-insensitive manner
        
    # Use regular expressions to find words, ignoring punctuation
    words = re.findall(r'\b\w+\b', text)
    
    # Count the frequency of each word
    word_counts = Counter(words)
    
    # Get the top N most common words
    most_common_words = word_counts.most_common(N)
    
    return most_common_words

# Example usage:
filename = 'romeo.txt'
N = 3
result = top_n_common_words(filename, N)
print(result)
