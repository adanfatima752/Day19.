def sort_dict_by_values(dictionary):
    return sorted(dictionary.items(), key=lambda item: item[1], reverse=True)

# Example usage:
my_dict = {'a': 10, 'b': 1, 'c': 22}
result = sort_dict_by_values(my_dict)
print(result)
