def max_in_tuple(numbers):
    """
    This function takes a tuple of numbers and returns the maximum value.
    """
    return max(numbers)

# Creating a tuple with three numerical values
values = (4, 7, 1)

# Getting the maximum value in the tuple
max_value = max_in_tuple(values)

# Printing the maximum value
print(max_value)
